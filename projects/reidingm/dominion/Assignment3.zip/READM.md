run make all #To compile the dominion code
run ./playdom 30 # to run playdom code
